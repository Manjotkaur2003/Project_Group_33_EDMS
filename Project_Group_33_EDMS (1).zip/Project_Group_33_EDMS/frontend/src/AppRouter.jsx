import { useState } from 'react';
import Login from './pages/Login';
import Dashboard from './pages/Dashboard';
import EmployeeList from './pages/EmployeeList';
import Profile from './pages/Profile';
import AddEmployee from './pages/AddEmployee';
import './App.css';

export default function AppRouter() {
  const [user, setUser] = useState(null);
  const [page, setPage] = useState('login');

  const handleLogin = (data) => {
    setUser(data.user);
    setPage('dashboard');
    localStorage.setItem('token', data.token);
  };

  const handleLogout = () => {
    setUser(null);
    setPage('login');
    localStorage.removeItem('token');
  };

  if (!user) {
    return <Login onLogin={handleLogin} />;
  }

  // Sidebar navigation links
  const sidebar = (
    <aside className="sidebar">
      <h3>Dashboard</h3>
      <ul>
        <li style={{cursor:'pointer'}} onClick={() => setPage('dashboard')}>Dashboard</li>
        <li style={{cursor:'pointer'}} onClick={() => setPage('employees')}>Employees</li>
        <li style={{cursor:'pointer'}} onClick={() => setPage('add')}>Add Employee</li>
        <li style={{cursor:'pointer'}} onClick={() => setPage('profile')}>Profile</li>
        <li style={{cursor:'pointer'}} onClick={handleLogout}>Logout</li>
      </ul>
    </aside>
  );

  return (
    <div className="dashboard-container">
      {sidebar}
      <main className="main-content">
        {page === 'dashboard' && <Dashboard user={user} />}
        {page === 'employees' && <EmployeeList />}
        {page === 'add' && <AddEmployee />}
        {page === 'profile' && <Profile user={user} />}
      </main>
    </div>
  );
}
