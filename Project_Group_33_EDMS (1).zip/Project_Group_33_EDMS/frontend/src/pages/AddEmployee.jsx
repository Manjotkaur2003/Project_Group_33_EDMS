import { useState } from 'react';

export default function AddEmployee() {
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [role, setRole] = useState('Employee');
  const [department, setDepartment] = useState('IT');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    setSuccess('');
    // Mock: always succeed
    setTimeout(() => {
      setSuccess('Employee created successfully!');
      setLoading(false);
      setFullName('');
      setEmail('');
      setPassword('');
      setRole('Employee');
      setDepartment('IT');
    }, 1000);
  };

  return (
    <div className="add-employee-container">
      <h2>Add New Employee</h2>
      <form onSubmit={handleSubmit} className="add-employee-form">
        <label>Full Name:</label>
        <input value={fullName} onChange={e => setFullName(e.target.value)} required />
        <label>Email:</label>
        <input type="email" value={email} onChange={e => setEmail(e.target.value)} required />
        <label>Password:</label>
        <input type="password" value={password} onChange={e => setPassword(e.target.value)} required />
        <label>Role:</label>
        <select value={role} onChange={e => setRole(e.target.value)}>
          <option value="Admin">Admin</option>
          <option value="Employee">Employee</option>
        </select>
        <label>Department:</label>
        <select value={department} onChange={e => setDepartment(e.target.value)}>
          <option value="IT">IT</option>
          <option value="HR">HR</option>
          <option value="Finance">Finance</option>
        </select>
        <button type="submit" className="create-btn" disabled={loading}>{loading ? 'Creating...' : 'CREATE EMPLOYEE'}</button>
        {error && <div className="error">{error}</div>}
        {success && <div className="success">{success}</div>}
      </form>
    </div>
  );
}
