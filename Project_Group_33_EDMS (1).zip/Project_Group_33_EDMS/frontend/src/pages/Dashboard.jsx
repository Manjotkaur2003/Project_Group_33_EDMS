export default function Dashboard({ user }) {
  // Mock data
  const employees = [
    { name: 'Admin User', email: 'admin@example.com', role: 'Admin' },
    { name: 'Employee One', email: 'emp1@example.com', role: 'Employee' }
  ];
  return (
    <>
      <nav className="top-navbar">Welcome, {user?.full_name || 'Admin User'}</nav>
      <div className="stats">
        <div>Total Employees: <b>{employees.length}</b></div>
        <div>Active: <b>{employees.length - 1}</b></div>
        <div>Admin Users: <b>1</b></div>
        <div>Departments: <b>6</b></div>
      </div>
      <section className="overview-table">
        <h4>Employees Overview</h4>
        <table>
          <thead>
            <tr>
              <th>Name</th>
              <th>Email</th>
              <th>Role</th>
            </tr>
          </thead>
          <tbody>
            {employees.map(emp => (
              <tr key={emp.email}>
                <td>{emp.name}</td>
                <td>{emp.email}</td>
                <td>{emp.role}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </section>
    </>
  );
}
