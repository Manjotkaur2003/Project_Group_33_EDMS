import { useState } from 'react';

const initialEmployees = [
  { id: 1, name: 'Admin User', email: 'admin@example.com', role: 'Admin' },
  { id: 2, name: 'Employee One', email: 'emp1@example.com', role: 'Employee' },
  { id: 3, name: 'Employee Two', email: 'emp2@example.com', role: 'Employee' }
];

export default function EmployeeList() {
  const [search, setSearch] = useState('');
  const [employees, setEmployees] = useState(initialEmployees);

  const filtered = employees.filter(e =>
    e.name.toLowerCase().includes(search.toLowerCase()) ||
    e.email.toLowerCase().includes(search.toLowerCase())
  );

  const handleAdd = () => {
    const newEmp = {
      id: employees.length + 1,
      name: `Employee ${employees.length + 1}`,
      email: `emp${employees.length + 1}@example.com`,
      role: 'Employee'
    };
    setEmployees([...employees, newEmp]);
  };

  return (
    <div className="employee-list-container">
      <h2>Employees</h2>
      <div className="search-bar">
        <input
          type="text"
          placeholder="Search..."
          value={search}
          onChange={e => setSearch(e.target.value)}
        />
        <button className="filter-btn">Filter</button>
      </div>
      <table className="employee-table">
        <thead>
          <tr>
            <th>Name</th>
            <th>Email</th>
            <th>Role</th>
            <th>Edit</th>
          </tr>
        </thead>
        <tbody>
          {filtered.map(emp => (
            <tr key={emp.id}>
              <td>{emp.name}</td>
              <td>{emp.email}</td>
              <td>{emp.role}</td>
              <td><button className="edit-btn">Edit</button></td>
            </tr>
          ))}
        </tbody>
      </table>
      <button className="add-employee-btn" onClick={handleAdd}>Add New Employee</button>
    </div>
  );
}
