import { useState } from 'react';

export default function Profile({ user }) {
  const [fullName, setFullName] = useState(user?.full_name || 'Admin User');
  const [email, setEmail] = useState(user?.email || 'admin@example.com');
  const [department, setDepartment] = useState('HR');
  const [role, setRole] = useState('Admin');
  const [success, setSuccess] = useState('');

  const handleSave = (e) => {
    e.preventDefault();
    setSuccess('Profile updated!');
    setTimeout(() => setSuccess(''), 1500);
  };

  return (
    <div className="profile-container">
      <h2>Profile</h2>
      <div className="profile-photo">[ Profile Photo Placeholder ]</div>
      <form className="profile-form" onSubmit={handleSave}>
        <label>Full Name:</label>
        <input value={fullName} onChange={e => setFullName(e.target.value)} />
        <label>Email:</label>
        <input value={email} onChange={e => setEmail(e.target.value)} />
        <label>Department:</label>
        <input value={department} onChange={e => setDepartment(e.target.value)} />
        <label>Role:</label>
        <input value={role} onChange={e => setRole(e.target.value)} />
        <button className="save-btn">Save Changes</button>
        {success && <div className="success">{success}</div>}
      </form>
    </div>
  );
}
