import express from "express";
import pool from "../db.js";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";

const router = express.Router();

// Register new user
router.post("/register", async (req, res) => {
    const { full_name, email, password, role_id } = req.body;

    const hashedPwd = await bcrypt.hash(password, 10);

    const result = await pool.query(
        "INSERT INTO users (full_name, email, password, role_id) VALUES ($1,$2,$3,$4) RETURNING *",
        [full_name, email, hashedPwd, role_id]
    );

    res.json({ message: "User registered", user: result.rows[0] });
});

// Login authentication
router.post("/login", async (req, res) => {
    const { email, password } = req.body;

    const user = await pool.query("SELECT * FROM users WHERE email=$1", [email]);

    if (user.rows.length === 0)
        return res.status(404).json({ message: "User not found" });

    const isMatch = await bcrypt.compare(password, user.rows[0].password);
    if (!isMatch)
        return res.status(400).json({ message: "Invalid password" });

    const token = jwt.sign(
        {
            id: user.rows[0].id,
            role: user.rows[0].role_id,
            email: user.rows[0].email
        },
        process.env.JWT_SECRET,
        { expiresIn: "2h" }
    );

    res.json({
        message: "Login successful",
        token,
        user: {
            id: user.rows[0].id,
            full_name: user.rows[0].full_name,
            email: user.rows[0].email,
            role_id: user.rows[0].role_id
        }
    });
});

export default router;
